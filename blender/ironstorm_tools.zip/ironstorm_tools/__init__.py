bl_info = {
    "name": "Iron Storm Model Tools",
    "author": "Iron Storm modding toolset",
    "version": (0, 3, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > Iron Storm",
    "description": "Export meshes straight into Iron Storm (2002): replace the visible mesh of a stock weapon / pickup model",
    "category": "Import-Export",
}

import os
import struct
import bpy
import numpy as np
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Matrix

from .ismap import bigfile, modelswap, objmodel, rigimport, pgemu, chunks as C
from .ismap.repack import read_map_bytes
from .ismap.texio import NpImage

# stock models that can be replaced (name -> what it is)
PRESETS = [
    ('smg_first.4x3', 'SMG (first person)', ''), ('handgun_first.4x3', 'Handgun (first person)', ''),
    ('knife_first.4x3', 'Knife (first person)', ''), ('snipe_first.4x3', 'Sniper rifle (first person)', ''),
    ('shotgun_first.4x3', 'Shotgun (first person)', ''), ('mg1_first.4x3', 'MG 1 (first person)', ''),
    ('mg2_first.4x3', 'MG 2 (first person)', ''), ('mg3_first.4x3', 'MG 3 (first person)', ''),
    ('mg4_first.4x3', 'MG 4 (first person)', ''), ('launcher_first.4x3', 'Launcher (first person)', ''),
    ('rocket_first.4x3', 'Rocket (first person)', ''), ('flame_first.4x3', 'Flamethrower (first person)', ''),
    ('smg.4x3', 'SMG (held by others)', ''), ('handgun.4x3', 'Handgun (held by others)', ''), ('knife.4x3', 'Knife (held by others)', ''),
    ('snipe.4x3', 'Sniper rifle (held by others)', ''), ('shotgun.4x3', 'Shotgun (held by others)', ''), ('mg1.4x3', 'MG 1 (held by others)', ''),
    ('rocket.4x3', 'Rocket launcher (held by others)', ''),
    ('handgun_ammo.4x3', 'Handgun ammo pickup', ''), ('shotgun_ammo.4x3', 'Shotgun ammo pickup', ''), ('snipe_ammo.4x3', 'Sniper ammo pickup', ''),
    ('rocket_ammo.4x3', 'Rocket ammo pickup', ''), ('medikit.4x3', 'Medikit pickup', ''), ('smedikit.4x3', 'Small medikit pickup', ''),
    ('CUSTOM', 'Other (type the file name)', ''),
]

# characters (NPCs, player, multiplayer skins): compressed skinned meshes + skeleton
CHARACTERS = [
    ('amedic_model.4x3', 'Amedic', ''),
    ('butcher_model.4x3', 'Butcher', ''),
    ('cadet_model.4x3', 'Cadet', ''),
    ('camouf_model.4x3', 'Camouf', ''),
    ('cecile_model.4x3', 'Cecile', ''),
    ('cobaye_model.4x3', 'Cobaye', ''),
    ('cook_model.4x3', 'Cook', ''),
    ('dogmaster_model.4x3', 'Dogmaster', ''),
    ('ecorch_model.4x3', 'Ecorch', ''),
    ('fscient_model.4x3', 'Fscient', ''),
    ('kasakh_model.4x3', 'Kasakh', ''),
    ('lobby_model.4x3', 'Lobby', ''),
    ('logan_model.4x3', 'Logan', ''),
    ('Mecca_model.4x3', 'Mecca', ''),
    ('medic_model.4x3', 'Medic', ''),
    ('mitchell_model.4x3', 'Mitchell', ''),
    ('nurse_model.4x3', 'Nurse', ''),
    ('officerone_model.4x3', 'Officerone', ''),
    ('officertwo_model.4x3', 'Officertwo', ''),
    ('relax_model.4x3', 'Relax', ''),
    ('russian_model.4x3', 'Russian', ''),
    ('scient_model.4x3', 'Scient', ''),
    ('sibbourrin1_model.4x3', 'Sibbourrin1', ''),
    ('sibbourrin2_model.4x3', 'Sibbourrin2', ''),
    ('siberian_model.4x3', 'Siberian', ''),
    ('sibsniper_model.4x3', 'Sibsniper', ''),
    ('sniper_model.4x3', 'Sniper', ''),
    ('supercadet_model.4x3', 'Supercadet', ''),
    ('trooper_model.4x3', 'Trooper', ''),
    ('ungern_model.4x3', 'Ungern', ''),
    ('wiz_model.4x3', 'Wiz', ''),
    ('worker_model.4x3', 'Worker', ''),
    ('wounded_model.4x3', 'Wounded', ''),
    ('M_Kasakh_B_model.4x3', 'Multiplayer Kasakh (blue team)', ''),
    ('M_Kasakh_R_model.4x3', 'Multiplayer Kasakh (red team)', ''),
    ('M_Lobby_B_model.4x3', 'Multiplayer Lobby (blue team)', ''),
    ('M_Lobby_R_model.4x3', 'Multiplayer Lobby (red team)', ''),
    ('M_Russian_B_model.4x3', 'Multiplayer Russian (blue team)', ''),
    ('M_Russian_R_model.4x3', 'Multiplayer Russian (red team)', ''),
    ('M_Sibbourrin_B_model.4x3', 'Multiplayer Sibbourrin (blue team)', ''),
    ('M_Sibbourrin_R_model.4x3', 'Multiplayer Sibbourrin (red team)', ''),
    ('M_Sibsniper_B_model.4x3', 'Multiplayer Sibsniper (blue team)', ''),
    ('M_Sibsniper_R_model.4x3', 'Multiplayer Sibsniper (red team)', ''),
    ('M_Speakrin_B_model.4x3', 'Multiplayer Speakrin (blue team)', ''),
    ('M_Speakrin_model.4x3', 'Multiplayer Speakrin (default)', ''),
    ('M_Speakrin_R_model.4x3', 'Multiplayer Speakrin (red team)', ''),
    ('M_Supercadet_B_model.4x3', 'Multiplayer Supercadet (blue team)', ''),
    ('M_Supercadet_R_model.4x3', 'Multiplayer Supercadet (red team)', ''),
    ('M_Trooper_B_model.4x3', 'Multiplayer Trooper (blue team)', ''),
    ('M_Trooper_R_model.4x3', 'Multiplayer Trooper (red team)', ''),
    ('M_Wiz_B_model.4x3', 'Multiplayer Wiz (blue team)', ''),
    ('M_Wiz_R_model.4x3', 'Multiplayer Wiz (red team)', ''),
]

# first-person arms (the hands you see holding the weapon)
ARMS = [
    ('russian_model_first.4x3', 'Russian arms (first person)', ''),
    ('kasakh_model_first.4x3', 'Kasakh arms (first person)', ''),
    ('Lobby_model_first.4x3', 'Lobby arms (first person)', ''),
    ('sibbourrin1_model_first.4x3', 'Sibbourrin arms (first person)', ''),
    ('sibsniper_model_first.4x3', 'Sibsniper arms (first person)', ''),
    ('supercadet_model_first.4x3', 'Supercadet arms (first person)', ''),
    ('trooper_model_first.4x3', 'Trooper arms (first person)', ''),
    ('wiz_model_first.4x3', 'Wiz arms (first person)', ''),
    ('M_Kasakh_B_model_first.4x3', 'Multiplayer Kasakh arms (blue)', ''),
    ('M_Kasakh_R_model_first.4x3', 'Multiplayer Kasakh arms (red)', ''),
    ('M_Lobby_B_model_first.4x3', 'Multiplayer Lobby arms (blue)', ''),
    ('M_Lobby_R_model_first.4x3', 'Multiplayer Lobby arms (red)', ''),
    ('M_Russian_B_model_first.4x3', 'Multiplayer Russian arms (blue)', ''),
    ('M_Russian_R_model_first.4x3', 'Multiplayer Russian arms (red)', ''),
    ('M_Sibbourrin_B_model_first.4x3', 'Multiplayer Sibbourrin arms (blue)', ''),
    ('M_Sibbourrin_R_model_first.4x3', 'Multiplayer Sibbourrin arms (red)', ''),
    ('M_Sibsniper_B_model_first.4x3', 'Multiplayer Sibsniper arms (blue)', ''),
    ('M_Sibsniper_R_model_first.4x3', 'Multiplayer Sibsniper arms (red)', ''),
    ('M_Speakrin_model_first.4x3', 'Multiplayer Speakrin arms (default)', ''),
    ('M_Speakrin_B_model_first.4x3', 'Multiplayer Speakrin arms (blue)', ''),
    ('M_Speakrin_R_model_first.4x3', 'Multiplayer Speakrin arms (red)', ''),
    ('M_Supercadet_B_model_first.4x3', 'Multiplayer Supercadet arms (blue)', ''),
    ('M_Supercadet_R_model_first.4x3', 'Multiplayer Supercadet arms (red)', ''),
    ('M_Trooper_B_model_first.4x3', 'Multiplayer Trooper arms (blue)', ''),
    ('M_Trooper_R_model_first.4x3', 'Multiplayer Trooper arms (red)', ''),
    ('M_wiz_B_model_first.4x3', 'Multiplayer Wiz arms (blue)', ''),
    ('M_wiz_R_model_first.4x3', 'Multiplayer Wiz arms (red)', ''),
]


class ISProps(PropertyGroup):
    mod_dir: StringProperty(name="Mod folder", subtype='DIR_PATH', description="Optional: the mod's source folder (the one with mod.json and the .map files). 'Export to mod' puts the model in its models subfolder, which build_mod.py ships with the mod")
    game_dir: StringProperty(name="Game folder", subtype='DIR_PATH', description="The Iron Storm folder (the one with Game.exe and Models.ibf)")
    preset: EnumProperty(name="Replace", items=PRESETS, default='smg_first.4x3', description="Which stock model to replace")
    character: EnumProperty(name="Character", items=CHARACTERS, default='russian_model.4x3', description="NPC / player / multiplayer model to import")
    arms: EnumProperty(name="Arms", items=ARMS, default='russian_model_first.4x3', description="First-person arms model to import")
    custom: StringProperty(name="File", default="smg_first.4x3", description="Stock model file name, e.g. smg_first.4x3")
    node: StringProperty(name="Mesh node", default="", description="Name of the mesh node inside the stock model to replace. Empty = the main one (use 'Show stock model' to list them)")
    fit: BoolProperty(name="Fit to stock size", default=True, description="Scale and centre the model to the size of the stock mesh. Turn off to use your coordinates as they are (use the reference box)")
    two_sided: BoolProperty(name="Double-sided", default=False, description="Add a reversed copy of every face so thin or open meshes (blades, cloth, planes) never vanish when seen from behind")
    keep_children: BoolProperty(name="Keep stock parts", default=False, description="Keep the stock model's other parts (magazine, buttons). They keep the stock texture")
    selected_only: BoolProperty(name="Selected only", default=True, description="Export only the selected objects (otherwise every visible mesh)")


def target_name(p):
    n = p.custom.strip() if p.preset == 'CUSTOM' else p.preset
    if n and '.' not in os.path.basename(n): n += '.4x3'
    return n


def game_dir(p):
    d = bpy.path.abspath(p.game_dir)
    if not (os.path.exists(os.path.join(d, 'Models.ibf')) or os.path.exists(os.path.join(d, 'Models.ibf.bak'))):
        raise RuntimeError("Set the Game folder to your Iron Storm folder (it must contain Models.ibf)")
    return d


def stock_bytes(d, name):
    for base in ('Models.ibf.bak', 'Models.ibf'):
        ibf = os.path.join(d, base); lst = os.path.join(d, base.replace('.ibf', '.lst'))
        if os.path.exists(ibf) and os.path.exists(lst):
            data = bigfile.read_file(ibf, lst, name)
            if data: return data
    raise RuntimeError("%s not found in %s" % (name, d))


# ---------------------------------------------------------------- mesh / texture extraction
def _image_of(mat):
    """The colour texture of a material: the image on Base Color, else any image texture node."""
    if not mat or not mat.use_nodes: return None
    nodes = mat.node_tree.nodes
    for n in nodes:
        if n.type == 'BSDF_PRINCIPLED':
            l = n.inputs['Base Color'].links
            if l and l[0].from_node.type == 'TEX_IMAGE' and l[0].from_node.image: return l[0].from_node.image
    for n in nodes:
        if n.type == 'TEX_IMAGE' and n.image: return n.image
    return None


def _color_of(mat):
    if mat and mat.use_nodes:
        for n in mat.node_tree.nodes:
            if n.type == 'BSDF_PRINCIPLED': return tuple(n.inputs['Base Color'].default_value)[:3]
    return tuple(mat.diffuse_color)[:3] if mat else (0.8, 0.8, 0.8)


def _pot(n, lo=4, hi=2048):
    n = max(lo, min(hi, n)); e = round(np.log2(n)); return int(2 ** e)


def _np_image(img):
    """Blender image -> NpImage (power of two, top row first)."""
    w, h = img.size
    W, H = _pot(w), _pot(h)
    src = img
    if (W, H) != (w, h):
        src = img.copy(); src.scale(W, H)
    px = np.array(src.pixels[:], dtype=np.float32).reshape(H, W, 4)
    if src is not img: bpy.data.images.remove(src)
    arr = np.clip(px * 255.0 + 0.5, 0, 255).astype(np.uint8)[::-1]      # Blender stores the bottom row first
    return NpImage(arr)


def _flat_image(rgb):
    arr = np.zeros((4, 4, 4), np.uint8); arr[..., :3] = [int(max(0, min(1, c)) * 255 + 0.5) for c in rgb]; arr[..., 3] = 255
    return NpImage(arr)


def gather(context, objs, weights=False):
    """Triangles [(texture key, [(pos, uv, normal) x3])] for the objects (world space) and {texture key: NpImage}."""
    dg = context.evaluated_depsgraph_get(); tris = []; textures = {}; keycache = {}
    for ob in objs:
        if ob.type != 'MESH': continue
        ev = ob.evaluated_get(dg); me = ev.to_mesh()
        try:
            me.calc_loop_triangles()
            if hasattr(me, 'corner_normals'): cn = [tuple(n.vector) if hasattr(n, 'vector') else tuple(n) for n in me.corner_normals]
            else:
                me.calc_normals_split(); cn = [tuple(l.normal) for l in me.loops]
            uvl = me.uv_layers.active.data if me.uv_layers.active else None
            mw = ev.matrix_world; nm = mw.to_3x3().inverted_safe().transposed()
            pos = [mw @ v.co for v in me.vertices]
            vgn = [g.name for g in ev.vertex_groups]
            vw = [[(vgn[g.group], g.weight) for g in v.groups if g.group < len(vgn)] for v in me.vertices] if weights else None
            mats = list(ob.material_slots)
            for t in me.loop_triangles:
                slot = mats[t.material_index].material if t.material_index < len(mats) else None
                ck = slot.name if slot else '_none'
                if ck not in keycache:
                    img = _image_of(slot)
                    if img:
                        key = os.path.splitext(img.name)[0].replace(' ', '_') + '.tga'
                        if key not in textures: textures[key] = _np_image(img)
                    else:
                        key = ('flat_' + ck).replace(' ', '_') + '.tga'
                        if key not in textures: textures[key] = _flat_image(_color_of(slot))
                    keycache[ck] = key
                vs = []
                for li, vi in zip(t.loops, t.vertices):
                    p = pos[vi]; n = (nm @ __import__('mathutils').Vector(cn[li])).normalized()
                    uv = tuple(uvl[li].uv) if uvl else (0.0, 0.0)
                    vs.append(((p.x, p.y, p.z), uv, (n.x, n.y, n.z), vw[vi]) if weights else ((p.x, p.y, p.z), uv, (n.x, n.y, n.z)))
                a, b, c = (vs[0][0], vs[1][0], vs[2][0])
                g = ((b[1]-a[1])*(c[2]-a[2]) - (b[2]-a[2])*(c[1]-a[1]), (b[2]-a[2])*(c[0]-a[0]) - (b[0]-a[0])*(c[2]-a[2]), (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0]))
                sn = [sum(v[2][i] for v in vs) for i in range(3)]
                if g[0]*sn[0] + g[1]*sn[1] + g[2]*sn[2] < 0: vs = [vs[0], vs[2], vs[1]]    # the game culls by winding: make it agree with the shading normals Blender shows
                tris.append((keycache[ck], vs))
        finally:
            ev.to_mesh_clear()
    return tris, textures


def _base_name(n):
    import re
    return re.sub(r'\.\d{3}$', '', n)


def _build_skinned(context, p, d, name, stock, ri, skin, objs):
    """Character / arms models: the mesh is skinned to the model's bones (vertex groups named like the bones the rig import made)."""
    objs = [o for o in objs if 'cbox' not in o.name.lower() and 'compressed mesh' not in o.name and o.display_type != 'WIRE']
    if not objs: raise RuntimeError("Select the character mesh (collision boxes are skipped)")
    arms = [m.object for o in objs for m in o.modifiers if m.type == 'ARMATURE' and m.object]
    saved = [(a.data, a.data.pose_position) for a in arms]
    for ad, _ in saved: ad.pose_position = 'REST'
    context.view_layer.update()
    try: tris, textures = gather(context, objs, weights=True)
    finally:
        for ad, pp in saved: ad.pose_position = pp
        context.view_layer.update()
    if not tris: raise RuntimeError("The selected objects have no faces")
    msgs = []
    if p.fit:       # centre the mesh over the stock skeleton (bones are in the model's own space; a mesh modelled elsewhere in the scene would hang in mid-air)
        bp = np.array([n['world'][:3, 3] for n in ri['nodes'] if n['kind'] == 'NODE' and n['defid'] is not None and 'Nub' not in n['name'] and 'Footsteps' not in n['name'] and 'Toe' not in n['name'] and 'Finger' not in n['name']])
        mp = np.array([v[0] for _, vs in tris for v in vs])
        if len(bp):
            sh = (bp.min(0) + bp.max(0)) / 2 - (mp.min(0) + mp.max(0)) / 2; sh[2] = 0.0
            if np.linalg.norm(sh) > 1e-4:
                tris = [(k, [((v[0][0] + sh[0], v[0][1] + sh[1], v[0][2]),) + tuple(v[1:]) for v in vs]) for k, vs in tris]
                msgs.append("  centred over the skeleton (moved %.2f, %.2f; turn 'Fit to stock size' off to keep your position)" % (sh[0], sh[1]))
    if p.two_sided: tris = tris + [(m, [(pp, uv, tuple(-c for c in nn), w) for pp, uv, nn, w in reversed(vs)]) for m, vs in tris]
    msgs.insert(0, "[build 3: %s, %d tris, skinned%s]" % (name, len(tris), ", double-sided" if p.two_sided else ""))
    data = modelswap.swap_skin(stock, tris, textures, ri['nodes'], skin['name'], log=msgs.append)
    return d, name, data, msgs


def build(context, p):
    """Objects named after a mesh node of the stock model (as the rig import names them) replace that node's geometry;
    every other object becomes the target node's mesh. Stock parts with no object in the scene are hidden (shrunk to a
    speck, the node stays because the game looks it up) unless 'Keep stock parts' is on."""
    objs = list(context.selected_objects if p.selected_only else context.visible_objects)
    objs = [o for o in objs if o.type == 'MESH' and not o.name.startswith('stock_bounds')]
    if not objs: raise RuntimeError("Select the mesh object(s) to export" if p.selected_only else "No visible mesh objects")
    d = game_dir(p); name = target_name(p)
    for o in objs:      # a mesh skinned to an imported rig goes back to the model that rig came from
        a = next((m.object for m in o.modifiers if m.type == 'ARMATURE' and m.object), None)
        if a is None: continue
        cand = a.get('ironstorm_file') or (a.name[:-4] + '.4x3' if a.name.endswith('_rig') else None)
        if cand:
            try: stock_bytes(d, cand); name = cand; break
            except RuntimeError: pass
    stock = stock_bytes(d, name)
    node = p.node.strip() or None
    ri = rigimport.load(stock)
    skin = next((n for n in ri['nodes'] if n['kind'] in ('PMSK', 'MESK') and (not node or n['name'] == node)), None)
    if skin is not None:
        return _build_skinned(context, p, d, name, stock, ri, skin, objs)
    ms = {n['name']: n for n in ri['nodes'] if n['kind'] in ('MESH', 'MESP')}
    nd = ms.get(node) if node else next(iter(ms.values()), None)
    tname = nd['name'] if nd else None
    groups = {}
    for o in objs:
        bn = _base_name(o.name)
        key = bn if (bn in ms and bn != tname) else tname
        groups.setdefault(key, []).append(o)
    if tname not in groups: groups[tname] = []
    textures = {}; parts = {}
    for key, gobs in groups.items():
        if not gobs: continue
        tris, tx = gather(context, gobs); textures.update(tx)
        if not tris: continue
        n = ms.get(key)
        if n is not None:
            Wi = np.linalg.inv(n['mesh_world']); R3n = np.linalg.inv(Wi[:3, :3]).T
            def tp(q, Wi=Wi): r = Wi @ np.array([q[0], q[1], q[2], 1.0]); return (float(r[0]), float(r[1]), float(r[2]))
            def tn(q, R3n=R3n):
                r = R3n @ np.array(q); l = np.linalg.norm(r) or 1.0; return (float(r[0]/l), float(r[1]/l), float(r[2]/l))
            tris = [(k, [(tp(a), uv, tn(nn)) for a, uv, nn in vs]) for k, vs in tris]
        fit = modelswap.mesh_bbox(stock, key) if (p.fit and key == tname) else None
        res = objmodel.transform(tris, 'zup', 1.0, (0, 0, 0), fit)
        if p.two_sided:
            res = res + [(m, [(pp, uv, tuple(-c for c in nn)) for pp, uv, nn in reversed(vs)]) for m, vs in res]
        parts[key] = res
    if tname not in parts: raise RuntimeError("Nothing to put on %s: the objects for it have no faces" % tname)
    msgs = ["[build 3: %d tris%s]" % (sum(len(v) for v in parts.values()), ", double-sided" if p.two_sided else "")]
    extra = {k: v for k, v in parts.items() if k != tname}
    data = modelswap.swap_mesh(stock, parts[tname], textures, tname, p.keep_children, log=msgs.append, extra=extra)
    if extra: msgs.append('  also replaced: ' + ', '.join(extra))
    return d, name, data, msgs


# ---------------------------------------------------------------- operators
class IS_OT_export(Operator):
    bl_idname = "ironstorm.export"; bl_label = "Export model file"
    bl_description = "Write the replacement .4x3 to a folder (nothing is installed)"
    directory: StringProperty(subtype='DIR_PATH'); filter_folder: BoolProperty(default=True, options={'HIDDEN'})
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self); return {'RUNNING_MODAL'}
    def execute(self, context):
        p = context.scene.ironstorm
        try:
            d, name, data, msgs = build(context, p)
            out = os.path.join(bpy.path.abspath(self.directory), name); open(out, 'wb').write(data)
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        self.report({'INFO'}, "Wrote %s (%d bytes)" % (out, len(data))); return {'FINISHED'}


class IS_OT_install(Operator):
    bl_idname = "ironstorm.install"; bl_label = "Export to game"
    bl_description = "Build the replacement model and save it as a loose file in the game's override folder (the mod loader loads it instead of the stock one). Models.ibf is not touched"
    def execute(self, context):
        p = context.scene.ironstorm
        try:
            d, name, data, msgs = build(context, p)
            od = os.path.join(d, 'override'); os.makedirs(od, exist_ok=True)
            open(os.path.join(od, name), 'wb').write(data)
        except PermissionError:
            self.report({'ERROR'}, "Models.ibf is in use - close the game first"); return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        self.report({'INFO'}, "%s saved to override (%d bytes). %s" % (name, len(data), ' '.join(m.strip() for m in msgs))); return {'FINISHED'}


class IS_OT_export_mod(Operator):
    bl_idname = "ironstorm.export_mod"; bl_label = "Export to mod"
    bl_description = "Build the replacement model and save it in the mod folder's models subfolder (shipped with the mod; the game folder is not touched)"
    def execute(self, context):
        p = context.scene.ironstorm
        if not p.mod_dir.strip():
            self.report({'ERROR'}, "Set the Mod folder first"); return {'CANCELLED'}
        try:
            d, name, data, msgs = build(context, p)
            md = os.path.join(bpy.path.abspath(p.mod_dir), 'models'); os.makedirs(md, exist_ok=True)
            open(os.path.join(md, name), 'wb').write(data)
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        self.report({'INFO'}, "%s saved to %s (%d bytes). %s" % (name, md, len(data), ' '.join(m.strip() for m in msgs))); return {'FINISHED'}


class IS_OT_restore(Operator):
    bl_idname = "ironstorm.restore"; bl_label = "Restore stock models"
    bl_description = "Remove the exported models from the override folder and put the original Models.ibf back"
    def execute(self, context):
        import shutil
        try:
            d = game_dir(context.scene.ironstorm)
            od = os.path.join(d, 'override')
            if os.path.isdir(od):
                for fn in os.listdir(od):
                    if fn.lower().endswith(('.4x3', '.4xt')): os.remove(os.path.join(od, fn))
            for f in ('Models.ibf', 'Models.lst'):
                if os.path.exists(os.path.join(d, f + '.bak')): shutil.copy2(os.path.join(d, f + '.bak'), os.path.join(d, f))
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        self.report({'INFO'}, "Override folder cleared, stock Models.ibf restored"); return {'FINISHED'}


def _mat(x):   # .4x3 'xfr' (row vectors, translation in the last row) -> Blender matrix
    return Matrix([x[0:4], x[4:8], x[8:12], x[12:16]]).transposed()


class IS_OT_reference(Operator):
    bl_idname = "ironstorm.reference"; bl_label = "Show stock model"
    bl_description = "Add the stock model's mesh bounds and its marker points (muzzle, ejection ...) as reference objects, and list its mesh nodes"
    def execute(self, context):
        p = context.scene.ironstorm
        try:
            d = game_dir(p); name = target_name(p); stock = stock_bytes(d, name)
            head, recs, tags, _ = read_map_bytes(stock)
            tree = C.parse(next(r for r, t in zip(recs, tags) if t == b'NODE'))
            meshes = C.find_lists(tree, b'MESH')
            node = p.node.strip(); m = next((x for x in meshes if x.name() == node), meshes[0])
            lo, hi = modelswap.mesh_bbox(stock, m.name())
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        coll = bpy.data.collections.get('IronStorm reference') or bpy.data.collections.new('IronStorm reference')
        if coll.name not in context.scene.collection.children: context.scene.collection.children.link(coll)
        def add(ob): coll.objects.link(ob); return ob
        # the box, in the mesh node's own frame (the frame the exported vertices live in)
        verts = [(x, y, z) for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]
        edges = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
        me = bpy.data.meshes.new('stock_bounds'); me.from_pydata(verts, edges, []); me.update()
        box = add(bpy.data.objects.new('stock_bounds (%s)' % m.name(), me)); box.display_type = 'WIRE'
        nd = next((n for n in rigimport.load(stock)['nodes'] if n['name'] == m.name()), None)
        if nd is not None: box.matrix_world = Matrix(nd['mesh_world'].tolist())
        for k in m.kids:
            if k.is_list and k.form in (b'NODE', b'MESH') and k.name():
                x = next((q.data for q in k.kids if q.cid in (b'xfr', b'\x11xfr')), None)
                e = bpy.data.objects.new(k.name(), None); e.empty_display_type = 'ARROWS'; e.empty_display_size = 0.15
                if x: e.matrix_world = _mat(struct.unpack('<16f', x[:64]))
                add(e)
        names = ', '.join(x.name() or '?' for x in meshes)
        self.report({'INFO'}, "Mesh nodes in %s: %s (showing %s). Barrel points along -Y, Z is up." % (name, names, m.name()))
        return {'FINISHED'}


def _stock_image(t):
    key = 'IS_' + t['name']
    if key in bpy.data.images: return bpy.data.images[key]
    path = os.path.join(bpy.app.tempdir, 'is_%d_%s.dds' % (t['id'], os.path.splitext(t['name'])[0]))
    with open(path, 'wb') as f: f.write(rigimport.dds_bytes(t))
    im = bpy.data.images.load(path); im.name = key; im.pack()
    return im


def _stock_material(t):
    name = 'IS_' + (t['name'] if t else 'none')
    if name in bpy.data.materials: return bpy.data.materials[name]
    m = bpy.data.materials.new(name); m.use_nodes = True
    if t:
        n = m.node_tree.nodes.new('ShaderNodeTexImage'); n.image = _stock_image(t); m.node_tree.nodes.active = n
        b = m.node_tree.nodes.get('Principled BSDF')
        if b: m.node_tree.links.new(n.outputs['Color'], b.inputs['Base Color'])
    return m


class IS_OT_import_rig(Operator):
    bl_idname = "ironstorm.import_rig"; bl_label = "Import stock model with rig"
    source: bpy.props.EnumProperty(items=[('WEAPON', 'Weapon', ''), ('CHARACTER', 'Character', ''), ('ARMS', 'Arms', '')], default='WEAPON', options={'HIDDEN'})
    bl_description = ("Import the stock model: its skeleton (rest pose) as an armature, its meshes with textures, "
                      "collision boxes (wire) and marker points. Character skins (compressed skinned meshes) cannot be read yet")
    def execute(self, context):
        p = context.scene.ironstorm
        try:
            d = game_dir(p); name = {'CHARACTER': p.character, 'ARMS': p.arms}.get(self.source) or target_name(p)
            dll = os.path.join(d, 'fnx_core.dll'); dll = dll if os.path.exists(dll) else None
            data = rigimport.load(stock_bytes(d, name), dll)
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        nodes = data['nodes']
        if not nodes:
            self.report({'ERROR'}, "%s has no node tree to import" % name); return {'CANCELLED'}
        if self.source in ('CHARACTER', 'ARMS'): p.preset = 'CUSTOM'; p.custom = name      # exports now go to the model just imported
        base = os.path.splitext(name)[0]
        coll = bpy.data.collections.new('IronStorm ' + base); context.scene.collection.children.link(coll)
        if context.object and context.object.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
        # --- armature from the NODE hierarchy (bones, dummies, markers)
        arm_d = bpy.data.armatures.new(base + '_rig'); arm = bpy.data.objects.new(base + '_rig', arm_d); arm['ironstorm_file'] = name
        coll.objects.link(arm); context.view_layer.objects.active = arm; arm.select_set(True)
        bone_of = {}
        bpy.ops.object.mode_set(mode='EDIT')
        idx = [i for i, n in enumerate(nodes) if n['kind'] == 'NODE']
        kids = {i: [j for j in idx if nodes[j]['parent'] == i] for i in idx}
        for i in idx:
            n = nodes[i]; eb = arm_d.edit_bones.new(n['name']); bone_of[i] = eb.name
            W = n['world']; head = W[:3, 3]; ax = W[:3, 0]
            if kids[i]:
                cp = [nodes[j]['world'][:3, 3] for j in kids[i]]
                near = min(cp, key=lambda c: np.linalg.norm(c - head)); d = near - head; L = np.linalg.norm(d)
                tail = head + d / L * min(L, 1.5) if L > 1e-4 else head + ax / max(np.linalg.norm(ax), 1e-6) * 0.3
            else: tail = head + ax / max(np.linalg.norm(ax), 1e-6) * 0.5
            if np.linalg.norm(tail - head) < 0.15: tail = head + ax / max(np.linalg.norm(ax), 1e-6) * 0.3
            eb.head = tuple(head); eb.tail = tuple(tail)
            try: eb.align_roll(tuple(W[:3, 2]))
            except Exception: pass
        for i in idx:
            par = nodes[i]['parent']
            while par >= 0 and par not in bone_of: par = nodes[par]['parent']
            if par >= 0: arm_d.edit_bones[bone_of[i]].parent = arm_d.edit_bones[bone_of[par]]
        bpy.ops.object.mode_set(mode='OBJECT')
        arm.show_in_front = True
        # --- meshes
        nmesh = 0
        for m in data['meshes']:
            if m['P'] is None:      # compressed mesh we cannot decode: show its bounding box so the node can be targeted for export
                b = m['bsph']; r = b[4]
                v = [(b[0] + x * r, b[1] + y * r, b[2] + z * r) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
                e = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
                me = bpy.data.meshes.new(m['name']); me.from_pydata(v, e, []); me.update()
                ob = bpy.data.objects.new(m['name'] + ' (compressed mesh)', me); coll.objects.link(ob); ob.display_type = 'WIRE'
                ob.matrix_world = Matrix(nodes[m['node']]['mesh_world'].tolist()); continue
            tids = []
            for t, _ in m['tris']:
                if t not in tids: tids.append(t)
            faces = [tuple(v for v, u in tri) for _, tri in m['tris']]
            me = bpy.data.meshes.new(m['name']); me.from_pydata([tuple(v) for v in m['P']], [], faces); me.update()
            for t in tids: me.materials.append(_stock_material(data['textures'].get(t)))
            if len(m['U']):
                uv = me.uv_layers.new(name='UVMap'); k = 0
                for (t, tri), poly in zip(m['tris'], me.polygons):
                    poly.material_index = tids.index(t)
                    for (v, u), li in zip(tri, poly.loop_indices):
                        uv.data[li].uv = (float(m['U'][u][0]), 1.0 - float(m['U'][u][1])) if u < len(m['U']) else (0, 0)
            ob = bpy.data.objects.new(m['name'], me); coll.objects.link(ob)
            W = Matrix(nodes[m['node']]['mesh_world'].tolist()) if not m.get('world_identity') else Matrix.Identity(4)
            par = nodes[m['node']]['parent']
            while par >= 0 and par not in bone_of: par = nodes[par]['parent']
            if m.get('skinned'):        # character skin: one bone per vertex (rigid), deformed by the armature
                ob.parent = arm; ob.matrix_world = W
                names = {nodes[i]['name']: bone_of[i] for i in bone_of}
                for bname, verts in m['vgroups']:
                    if bname in names: ob.vertex_groups.new(name=names[bname]).add([int(v) for v in verts], 1.0, 'REPLACE')
                md = ob.modifiers.new('Armature', 'ARMATURE'); md.object = arm
            else:
                if par >= 0:
                    ob.parent = arm; ob.parent_type = 'BONE'; ob.parent_bone = bone_of[par]
                ob.matrix_world = W
            if m['collision']: ob.display_type = 'WIRE'; ob.hide_render = True
            nmesh += 1
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for sp in area.spaces:
                    if sp.type == 'VIEW_3D' and sp.shading.type == 'SOLID': sp.shading.color_type = 'TEXTURE'
        msg = "Imported %s: %d bones, %d meshes." % (name, len(idx), nmesh)
        if data['skinned']:
            if not pgemu.available(): msg += " Compressed meshes need the decoder: press 'Install mesh decoder' in the panel. Shown as boxes: %s" % ', '.join(data['skinned'][:3])
            elif not dll: msg += " Compressed meshes need fnx_core.dll in the game folder. Shown as boxes: %s" % ', '.join(data['skinned'][:3])
            else: msg += " Could not decode: %s" % ', '.join(data['skinned'][:3])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class IS_OT_install_decoder(Operator):
    bl_idname = "ironstorm.install_decoder"; bl_label = "Install mesh decoder"
    bl_description = "Installs the 'unicorn' Python package into Blender (needs internet). Used to read compressed character/weapon meshes"
    def execute(self, context):
        import subprocess, sys
        try:
            subprocess.check_call([sys.executable, '-m', 'ensurepip'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception: pass
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--upgrade', 'unicorn'])
            import importlib; importlib.invalidate_caches()
        except Exception as e:
            self.report({'ERROR'}, "Install failed: %s (run Blender as administrator, or install 'unicorn' into Blender's Python manually)" % e); return {'CANCELLED'}
        self.report({'INFO'}, "Decoder installed" if pgemu.available() else "Installed - restart Blender"); return {'FINISHED'}


class IS_PT_panel(Panel):
    bl_label = "Iron Storm (build 3)"; bl_idname = "IS_PT_panel"; bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = "Iron Storm"
    def draw(self, context):
        p = context.scene.ironstorm; l = self.layout
        l.prop(p, 'game_dir')
        l.prop(p, 'mod_dir')
        box = l.box(); box.label(text="Replace this stock model")
        box.prop(p, 'preset', text="")
        if p.preset == 'CUSTOM': box.prop(p, 'custom')
        box.prop(p, 'node')
        box.label(text="Export target: " + target_name(p), icon='EXPORT')
        box.operator('ironstorm.import_rig', text="Import stock model with rig", icon='ARMATURE_DATA').source = 'WEAPON'
        box.operator('ironstorm.reference', icon='MESH_CUBE')
        cb = l.box(); cb.label(text="NPC / player models")
        cb.prop(p, 'character', text="")
        cb.operator('ironstorm.import_rig', text="Import character with rig", icon='ARMATURE_DATA').source = 'CHARACTER'
        ab = l.box(); ab.label(text="First-person arms")
        ab.prop(p, 'arms', text="")
        ab.operator('ironstorm.import_rig', text="Import arms with rig", icon='ARMATURE_DATA').source = 'ARMS'
        if not pgemu.available(): l.operator('ironstorm.install_decoder', icon='IMPORT')
        col = l.column(align=True)
        col.prop(p, 'selected_only'); col.prop(p, 'fit'); col.prop(p, 'keep_children'); col.prop(p, 'two_sided')
        l.label(text="Model in the stock convention: Z up,")
        l.label(text="barrel toward -Y. UV-map it and give it")
        l.label(text="an image texture (Base Color).")
        l.operator('ironstorm.install', icon='EXPORT')
        r = l.row(); r.enabled = bool(p.mod_dir.strip()); r.operator('ironstorm.export_mod', icon='PACKAGE')
        l.operator('ironstorm.export', icon='FILE_FOLDER')
        l.operator('ironstorm.restore', icon='LOOP_BACK')


classes = (ISProps, IS_OT_export, IS_OT_install, IS_OT_export_mod, IS_OT_restore, IS_OT_reference, IS_OT_import_rig, IS_OT_install_decoder, IS_PT_panel)

def register():
    for c in classes: bpy.utils.register_class(c)
    bpy.types.Scene.ironstorm = bpy.props.PointerProperty(type=ISProps)

def unregister():
    del bpy.types.Scene.ironstorm
    for c in reversed(classes): bpy.utils.unregister_class(c)
