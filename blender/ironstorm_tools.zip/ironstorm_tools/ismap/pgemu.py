"""Decode the engine's compressed progressive meshes (MESP/PRGM = static, PMSK/PSKM = skinned) by running the
game's own loader code (fnx_core.dll) in an x86 emulator (pip package 'unicorn'). Needs the game's fnx_core.dll."""
import struct

_CTOR = {b'PRGM': 0x10035000, b'PSKM': 0x1003b9c0}      # object constructors inside fnx_core.dll (v1.041)
_LEVEL_STEP = 0x1003a3b0


class DecoderError(Exception): pass


def available():
    try:
        import unicorn  # noqa
        return True
    except Exception:
        return False


class _Emu:
    def __init__(self, dll_path):
        from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
        self.uc = Uc(UC_ARCH_X86, UC_MODE_32)
        data = open(dll_path, 'rb').read(); self.data = data
        pe = struct.unpack_from('<I', data, 0x3c)[0]
        nsec, = struct.unpack_from('<H', data, pe + 6); osz, = struct.unpack_from('<H', data, pe + 20)
        opt = pe + 24
        self.base, = struct.unpack_from('<I', data, opt + 28)
        size, = struct.unpack_from('<I', data, opt + 56); hdr, = struct.unpack_from('<I', data, opt + 60)
        if self.base != 0x10000000 or data[pe:pe + 4] != b'PE\0\0': raise DecoderError('unexpected fnx_core.dll')
        self.uc.mem_map(self.base, (size + 0xfff) & ~0xfff)
        self.uc.mem_write(self.base, data[:hdr])
        for i in range(nsec):
            s = opt + osz + 40 * i
            vsz, va, rsz, raw = struct.unpack_from('<IIII', data, s + 8)
            self.uc.mem_write(self.base + va, data[raw:raw + rsz])
        self.uc.mem_map(0x20000000, 0x10000000); self.heap = 0x20001000; self.sizes = {}
        self.uc.mem_map(0x30000000, 0x100000); self.sp0 = 0x30000000 + 0xf0000
        self.uc.mem_map(0x40000000, 0x100000)
        self.uc.mem_map(0x70000000, 0x10000); self.stubs = {}; self.nstub = 1
        self.uc.mem_write(0x70000000, b'\xc3' * 0x10000)
        self.uc.hook_add(UC_HOOK_CODE, self._on_code, begin=0x70000000, end=0x70010000)
        # imports: every one becomes a stub; the allocator ones are real
        impl = {b'malloc': self._malloc, b'??2@YAPAXI@Z': self._malloc, b'free': self._free, b'??3@YAXPAX@Z': self._free,
                b'calloc': self._calloc, b'realloc': self._realloc, b'memmove': self._memmove}
        idir, = struct.unpack_from('<I', data, opt + 104)
        def off(rva):
            for i in range(nsec):
                s = opt + osz + 40 * i; vsz, va, rsz, raw = struct.unpack_from('<IIII', data, s + 8)
                if va <= rva < va + max(vsz, rsz): return raw + rva - va
        o = off(idir)
        while o is not None:
            oft, _, _, name, ft = struct.unpack_from('<IIIII', data, o)
            if not name: break
            t = off(oft or ft); k = 0
            while True:
                v, = struct.unpack_from('<I', data, t + 4 * k)
                if not v: break
                nm = data[off(v) + 2:].split(b'\0')[0] if not v & 0x80000000 else b''
                a = self._stub(impl.get(nm, lambda: 0))
                self.uc.mem_write(self.base + ft + 4 * k, struct.pack('<I', a)); k += 1
            o += 20

    def _stub(self, fn, nargs=0):
        a = 0x70000000 + 4 * self.nstub; self.nstub += 1; self.stubs[a] = fn
        self.uc.mem_write(a, (b'\xc2' + bytes([4 * nargs, 0])) if nargs else b'\xc3'); return a

    def _on_code(self, uc, addr, size, ud):
        fn = self.stubs.get(addr)
        if fn:
            from unicorn.x86_const import UC_X86_REG_EAX
            r = fn()
            if r is not None: uc.reg_write(UC_X86_REG_EAX, r & 0xffffffff)

    def arg(self, n):
        from unicorn.x86_const import UC_X86_REG_ESP
        return struct.unpack('<I', self.uc.mem_read(self.uc.reg_read(UC_X86_REG_ESP) + 4 + 4 * n, 4))[0]
    def alloc(self, n):
        n = (max(n, 1) + 15) & ~15; a = self.heap; self.heap += n + 16; self.sizes[a] = n; return a
    def _malloc(self): return self.alloc(self.arg(0))
    def _calloc(self): return self.alloc(self.arg(0) * self.arg(1))
    def _free(self): return 0
    def _realloc(self):
        p, n = self.arg(0), self.arg(1); a = self.alloc(n)
        if p: self.uc.mem_write(a, bytes(self.uc.mem_read(p, min(self.sizes.get(p, 0), n))))
        return a
    def _memmove(self):
        d, s, n = self.arg(0), self.arg(1), self.arg(2); self.uc.mem_write(d, bytes(self.uc.mem_read(s, n))); return d
    def w(self, a, b): self.uc.mem_write(a, b)
    def r(self, a, n): return bytes(self.uc.mem_read(a, n))
    def u32(self, a): return struct.unpack('<I', self.r(a, 4))[0]

    def call(self, addr, args=(), ecx=None, maxins=200_000_000):
        from unicorn.x86_const import UC_X86_REG_ESP, UC_X86_REG_ECX
        esp = self.sp0
        for a in reversed(args): esp -= 4; self.uc.mem_write(esp, struct.pack('<I', a & 0xffffffff))
        esp -= 4; self.uc.mem_write(esp, struct.pack('<I', 0x7000ff00))
        self.uc.reg_write(UC_X86_REG_ESP, esp)
        if ecx is not None: self.uc.reg_write(UC_X86_REG_ECX, ecx)
        self.uc.emu_start(addr, 0x7000ff00, count=maxins)

    def stream(self, buf, tag):
        addr = 0x40000000; st = {'pos': 0}; vt = addr + 0x100
        self.w(addr, struct.pack('<I', vt))
        def read():
            d, n = self.arg(0), self.arg(1); self.w(d, buf[st['pos']:st['pos'] + n].ljust(n, b'\0')); st['pos'] += n; return n
        for off, fn, na in ((0x1c, lambda: len(buf), 0), (0x20, lambda: st['pos'], 0), (0x30, read, 2),
                            (0x48, lambda: 1 if self.arg(0) == tag else 0, 1)):
            self.w(vt + off, struct.pack('<I', self._stub(fn, na)))
        return addr


def decode(dll_path, kids, kind):
    """kids: chunks of a PRGM / PSKM list. -> dict(P, N, U, faces=[(v0,v1,v2)], uvfaces, texture, skin=None|dict)"""
    if not available(): raise DecoderError("the 'unicorn' Python package is not installed")
    em = _EMU_CACHE.get(dll_path)
    em = _Emu(dll_path)                               # fresh machine per mesh (state lives in the object)
    size = 0x400; obj = em.alloc(size); em.w(obj, b'\0' * size)
    em.call(_CTOR[kind], ecx=obj)
    fn = em.u32(em.u32(obj) + 4 * 5)
    tex = mat = None
    for k in kids:
        if k.is_list: continue
        if k.cid == b'TEXU' and len(k.data) >= 4: tex = struct.unpack('<I', k.data[:4])[0]; continue
        if k.cid == b'MATL' and len(k.data) >= 4: mat = struct.unpack('<I', k.data[:4])[0]; continue
        tag = struct.unpack('<I', k.cid)[0]
        em.call(fn, args=(tag, em.stream(k.data, tag)), ecx=obj)
    vt = em.u32(obj)
    em.call(em.u32(vt + 0x7c), ecx=obj)                                         # prepare
    em.call(em.u32(vt + 0x80), args=(obj + 0x9c, struct.unpack('<I', struct.pack('<f', -1.0))[0]), ecx=obj)
    n = 0
    while em.u32(obj + 0xb0) < em.u32(obj + 0x90) and n < 100000: em.call(_LEVEL_STEP, ecx=obj); n += 1
    nv = em.u32(obj + 0xac); nf = em.u32(obj + 0xa8); pp = em.u32(obj + 0x14); pn = em.u32(obj + 0x1c)
    nu = em.u32(obj + 0x30); pu = em.u32(obj + 0x2c); pc = em.u32(obj + 0x9c)
    P = [struct.unpack('<3f', em.r(pp + 16 * i, 12)) for i in range(nv)]
    N = [struct.unpack('<3f', em.r(pn + 16 * i, 12)) for i in range(min(nv, em.u32(obj + 0x20)))]
    U = [struct.unpack('<2f', em.r(pu + 8 * i, 8)) for i in range(nu)]
    F = []; FU = []
    for i in range(nf):
        c = struct.unpack('<6H', em.r(pc + 12 * i, 12)); F.append((c[0], c[2], c[4])); FU.append((c[1], c[3], c[5]))
    out = {'P': P, 'N': N, 'U': U, 'F': F, 'FU': FU, 'texture': tex, 'material': mat, 'skin': None}
    if kind == b'PSKM':
        ng = em.u32(obj + 0xf4); pa = em.u32(obj + 0xf8); nvm = em.u32(obj + 0x100); va = em.u32(obj + 0x104)
        groups = [struct.unpack('<3fIIII', em.r(pa + 28 * i, 28))[5:] for i in range(ng)]       # (start, count) into vmap
        vmap = [struct.unpack('<I', em.r(va + 8 * i, 4))[0] for i in range(nvm)]
        out['skin'] = {'groups': groups, 'vmap': vmap}
    return out


_EMU_CACHE = {}
