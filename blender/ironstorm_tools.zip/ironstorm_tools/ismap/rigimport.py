"""Read a stock .4x3 model: skeleton (rest pose), PRIM meshes, textures. Pure python + numpy, no bpy."""
import struct
import numpy as np
from . import chunks as C
from .repack import read_map_bytes


def _qmat(q):
    x, y, z, w = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def _first_keys(node):
    pos = rot = None
    for pl in node.kids:
        if pl.is_list and pl.form == b'plug':
            for pr in pl.kids:
                if pr.is_list and pr.form == b'PRSC':
                    ks = [k for k in pr.kids if k.is_list and k.form == b'plug'][0].kids
                    for i, k in enumerate(ks):
                        if k.is_list and k.form == b'IERP':
                            nm = ks[i - 1].cid
                            for x in k.kids:
                                if x.is_list:
                                    for kk in x.kids:
                                        if kk.cid == b'keys':
                                            d = kk.data
                                            if nm.endswith(b'pos') and len(d) >= 16: pos = struct.unpack_from('<3f', d, 4)
                                            elif nm.endswith(b'rot') and len(d) >= 20: rot = struct.unpack_from('<4f', d, 4)
    return pos, rot


def _local(node):
    m = np.eye(4)
    pos, rot = _first_keys(node)
    if pos is not None or rot is not None:
        if rot is not None: m[:3, :3] = _qmat(rot)
        if pos is not None: m[:3, 3] = pos
        return m
    for k in node.kids:
        if not k.is_list and k.cid in (b'xfr', b'\x11xfr') and len(k.data) >= 64:
            return np.array(struct.unpack('<16f', k.data[:64])).reshape(4, 4).T
    return m


def decode_prim(vrtx, face, indx):
    n = struct.unpack_from('<I', vrtx, 4)[0]; o = 8
    P = np.frombuffer(vrtx, '<f4', 4 * n, o).reshape(n, 4)[:, :3].copy(); o += 16 * n
    nn = struct.unpack_from('<I', vrtx, o)[0]; o += 4 + 16 * nn
    nu = 0   # skip any colour arrays: the uv count is the first word whose uvs + the 28-byte tail end the buffer
    for q in range(o, len(vrtx) - 3, 4):
        c = struct.unpack_from('<I', vrtx, q)[0]
        if c and len(vrtx) - (q + 4) in (8 * c + 28, 8 * c): nu = c; o = q + 4; break
    U = np.frombuffer(vrtx, '<f4', 2 * nu, o).reshape(nu, 2).copy() if nu else np.zeros((0, 2))
    N = np.frombuffer(vrtx, '<f4', 4 * nn, 8 + 16 * n + 4).reshape(nn, 4)[:, :3].copy() if nn else None
    fc = struct.unpack('<%dI' % (len(face) // 4), face); ix = struct.unpack('<%dI' % (len(indx) // 4), indx)
    tris = []; tex = None; cur = 0

    def agree(t):
        a, b, c = [P[v] for v, u in t]
        g = np.cross(b - a, c - a)
        return sum(float(g @ N[v]) for v, u in t if v < len(N)) if N is not None else 0
    for i in range(0, len(fc), 2):
        cmd, arg = fc[i], fc[i + 1]
        if cmd == 0x80: tex = arg
        elif cmd == 4:
            ents = [(e & 0xffff, e >> 16) for e in ix[cur:cur + arg]]; cur += arg
            for k in range(0, len(ents) - 2, 3): tris.append((tex, ents[k:k + 3]))
        elif cmd == 16:                     # arg entries forming one strip / fan
            ents = [(e & 0xffff, e >> 16) for e in ix[cur:cur + arg]]; cur += arg
            if len(ents) >= 3:
                strip = [ents[k:k + 3] if k % 2 == 0 else [ents[k + 1], ents[k], ents[k + 2]] for k in range(len(ents) - 2)]
                fan = [[ents[0], ents[k], ents[k + 1]] for k in range(1, len(ents) - 1)]
                pick = strip
                tris += [(tex, t) for t in pick]
        elif cmd == 5:
            for _ in range(arg):
                cnt = ix[cur]; ents = [(e & 0xffff, e >> 16) for e in ix[cur + 1:cur + 1 + cnt]]; cur += 1 + cnt
                strip = [ents[k:k + 3] if k % 2 == 0 else [ents[k + 1], ents[k], ents[k + 2]] for k in range(len(ents) - 2)]
                fan = [[ents[0], ents[k], ents[k + 1]] for k in range(1, len(ents) - 1)]
                pick = strip              # always strips (fans leave far more open edges)
                tris += [(tex, t) for t in pick]
    return P, U, tris


def _prg_mesh(dec, name, idx):
    P = np.array(dec['P'], float).reshape(-1, 3); U = np.array(dec['U'], float).reshape(-1, 2)
    tris = [(dec['texture'], [(v, u) for v, u in zip(f, fu)]) for f, fu in zip(dec['F'], dec['FU'])]
    N = np.array(dec['N'], float).reshape(-1, 3)
    if len(N) == len(P) and tris:       # keep the winding on the side the stored normals face (visible side = cross(v1-v0, v2-v0))
        s = 0.0
        for _, t in tris:
            a, b, c = (P[v] for v, _ in t); g = np.cross(b - a, c - a); s += float(g @ (N[t[0][0]] + N[t[1][0]] + N[t[2][0]]))
        if s < 0: tris = [(x, [t[0], t[2], t[1]]) for x, t in tris]
    return {'name': name, 'node': idx, 'P': P, 'U': U, 'tris': tris, 'hidden': False, 'collision': False}


def load(data, dll=None):
    """-> dict(nodes=[...], meshes=[...], textures={id: dict}, skinned=[names])"""
    head, recs, tags, _ = read_map_bytes(data)
    tex = {}
    for r, t in zip(recs, tags):
        if t != b'TEXU': continue
        d = {'id': None, 'name': '', 'fmt': None}
        for c in C.parse(r):
            if c.cid == b'def!': d['id'] = struct.unpack('<I', c.data[:4])[0]
            elif c.cid == b'@nam': d['name'] = c.data.split(b'\0')[0].decode('latin1')
            elif c.is_list and c.form == b'IMAG':
                for k in c.kids:
                    if k.cid == b'info': d['fmt'] = k.data[:4]; d['w'], d['h'], d['mips'] = struct.unpack('<3I', k.data[4:16])
                    elif k.cid == b'bufr': d['buf'] = k.data
        if d['id'] is not None and d.get('buf'): tex[d['id']] = d
    rec = next(((x, t) for x, t in zip(recs, tags) if t in (b'NODE', b'MESH')), None)
    if rec is None: return {'nodes': [], 'meshes': [], 'textures': tex, 'skinned': []}
    tree = C.parse(rec[0])
    if any(c.cid == b'@nam' for c in tree): tree = [C.Chunk(b'LIST', form=rec[1], kids=tree)]      # the record is the root node itself (pickups, held weapons)
    nodes = []; meshes = []; skinned = []; pending = []

    def walk(c, parent, W):
        for k in c.kids if hasattr(c, 'kids') else c:
            if not (k.is_list and k.form in (b'NODE', b'MESH', b'MESP', b'PMSK', b'MESK')): continue
            Wk = W @ _local(k); name = k.name() or '?'
            idx = len(nodes)
            pv = next((x.data for x in k.kids if x.cid == b'pvot' and len(x.data) >= 64), None)
            Pm = np.array(struct.unpack('<16f', pv[:64])).reshape(4, 4).T if pv else np.eye(4)
            # vertices live in the pivot frame: scene position = node world * pvot * vertex
            did = next((struct.unpack('<I', x.data[:4])[0] for x in k.kids if x.cid == b'def!' and not x.is_list and len(x.data) >= 4), None)
            nodes.append({'name': name, 'parent': parent, 'world': Wk, 'mesh_world': Wk @ Pm, 'kind': k.form.decode(), 'defid': did})
            if k.form == b'MESH':
                vis = next((x.data for x in k.kids if x.cid == b'\x01vis'), None)
                prims = [x for x in k.kids if x.is_list and x.form == b'PRIM']
                for mt in k.kids:
                    if mt.is_list and mt.form == b'MTGM': prims += [x for x in mt.kids if x.is_list and x.form == b'PRIM']
                for pi, pr in enumerate(prims):
                    try:
                        P, U, tris = decode_prim(next(x for x in pr.kids if x.cid == b'vrtx').data,
                                                 next(x for x in pr.kids if x.cid == b'face').data,
                                                 next(x for x in pr.kids if x.cid == b'indx').data)
                        meshes.append({'name': name if pi == 0 else '%s_part%d' % (name, pi + 1), 'node': idx, 'P': P, 'U': U, 'tris': tris,
                                       'hidden': bool(vis is not None and len(vis) >= 1 and vis[0] == 0),
                                       'collision': 'cbox' in name})
                    except Exception as e:
                        skinned.append(name + ' (' + str(e) + ')')
            if k.form == b'MESK':       # uncompressed skinned mesh (first-person arms): PRIM-style data + rigid limb ranges
                sk = next((x for x in k.kids if x.is_list and x.form == b'SKIM'), None)
                bl = next((x for x in k.kids if x.is_list and x.form == b'bone'), None)
                if sk is not None:
                    try:
                        g = lambda c: next(x for x in sk.kids if x.cid == c).data
                        P, U, tris = decode_prim(g(b'vrtx'), g(b'face'), g(b'indx'))
                        limb = g(b'limb'); ids = [struct.unpack('<I', x.data[:4])[0] for x in bl.kids if not x.is_list] if bl is not None else []
                        groups = [struct.unpack_from('<2I', limb, 28 * i + 20) for i in range(len(limb) // 28)]
                        mm = {'name': name, 'node': idx, 'P': P, 'U': U, 'tris': tris, 'hidden': False, 'collision': False, 'bone_local': True}
                        pending.append((mm, {'groups': groups, 'vmap': list(range(len(P)))}, ids))
                        meshes.append(mm)
                    except Exception as e:
                        skinned.append('%s (%s)' % (name, e))
            if k.form in (b'MESP', b'PMSK'):
                kind = b'PRGM' if k.form == b'MESP' else b'PSKM'
                pg = next((x for x in k.kids if x.is_list and x.form == kind), None)
                dec = None
                if pg is not None and dll:
                    try:
                        from . import pgemu
                        dec = pgemu.decode(dll, pg.kids, kind)
                    except Exception as e:
                        skinned.append('%s (%s)' % (name, e))
                if dec is not None:
                    mm = _prg_mesh(dec, name, idx)
                    if kind == b'PSKM':
                        bl = next((x for x in k.kids if x.is_list and x.form == b'bone'), None)
                        if bl is not None and dec['skin']:
                            ids = [struct.unpack('<I', x.data[:4])[0] for x in bl.kids if not x.is_list]
                            pending.append((mm, dec['skin'], ids))
                    meshes.append(mm)
                else:
                    bs = next((x.data for x in (pg.kids if pg else []) if x.cid == b'bsph'), None)
                    if bs: meshes.append({'name': name, 'node': idx, 'bsph': struct.unpack('<5f', bs), 'P': None, 'U': None, 'tris': [], 'hidden': False, 'collision': False})
                    if not any(name in s for s in skinned): skinned.append(name)
            walk(k, idx, Wk)
    walk(tree, -1, np.eye(4))
    bydef = {n['defid']: n['name'] for n in nodes if n['defid'] is not None}
    for mm, sk, ids in pending:
        vg = []
        for g, (s, c) in enumerate(sk['groups']):
            if g < len(ids) and ids[g] in bydef: vg.append((bydef[ids[g]], sk['vmap'][s:s + c]))
        if mm.get('bone_local'):         # vertices are stored in their bone's own frame: bring them to the rest pose
            bw = {n['name']: n['world'] for n in nodes}; P = mm['P'].copy()
            for bname, verts in vg:
                W = bw[bname]; v = np.array(verts, int); P[v] = (W[:3, :3] @ P[v].T).T + W[:3, 3]
            mm['P'] = P
        mm['vgroups'] = vg; mm['skinned'] = True; mm['world_identity'] = True
    return {'nodes': nodes, 'meshes': meshes, 'textures': tex, 'skinned': skinned}


def dds_bytes(t):
    """DXT1/DXT5 texture dict -> .dds file bytes (top mip level only; Blender is picky about partial mip chains)."""
    w, h, fmt = t['w'], t['h'], t['fmt']
    size = max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * (16 if fmt == b'DXT5' else 8)
    hdr = struct.pack('<4s7I44x', b'DDS ', 124, 0x1 | 0x2 | 0x4 | 0x1000 | 0x80000, h, w, size, 0, 1)
    hdr += struct.pack('<2I4s5I', 32, 4, fmt, 0, 0, 0, 0, 0) + struct.pack('<5I', 0x1000, 0, 0, 0, 0)
    return hdr + t['buf'][:size]
