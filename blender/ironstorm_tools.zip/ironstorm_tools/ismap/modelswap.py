"""Replace the visible mesh of a stock Iron Storm model (weapon, pickup, ...) with a mesh imported from an .obj, keeping the
model's node tree (muzzle / ejection dummies, pivots) so the game still finds what it attaches things to."""
import struct, os
from . import chunks as C
from .repack import read_map_bytes, write_map
from .scene import texture_record, f4, u4, chunk, lst, sphere, HEAD
from .texio import encode_dxt1

def _pot(im):
    w, h = im.size; W = max(4, 1 << (w - 1).bit_length()); H = max(4, 1 << (h - 1).bit_length())
    return im if (W, H) == (w, h) else im.resize((W, H))

def build_prim(tris, tex_id, mat_id):
    """tris: [(texture key, [(pos, uv, normal) x3])] -> a LIST PRIM chunk. Vertices are shared by (pos, normal), uvs separately."""
    keys = []
    for t, _ in tris:
        if t not in keys: keys.append(t)
    vmap, pos, nrm, umap, uvs = {}, [], [], {}, []
    face = [(0x90, mat_id)]; indx = []; first = True
    for key in keys:
        group = [vs for t, vs in tris if t == key]
        face.append((0x80, tex_id[key]))
        if first: face.append((0x1000, 0x10002)); first = False
        for vs in group:
            indx.append(3)
            for p, uv, n in vs:
                vk = (tuple(round(x, 5) for x in p), tuple(round(x, 4) for x in n))
                if vk not in vmap: vmap[vk] = len(pos); pos.append(p); nrm.append(n)
                uk = (round(uv[0], 5), round(uv[1], 5))
                if uk not in umap: umap[uk] = len(uvs); uvs.append((uv[0], 1.0 - uv[1]))     # obj v runs bottom-up
                indx.append(vmap[vk] | (umap[uk] << 16))
        face.append((5, len(group)))
    if len(pos) > 65535 or len(uvs) > 65535: raise ValueError('mesh too big: %d vertices / %d uvs (limit 65535)' % (len(pos), len(uvs)))
    c, r = sphere(pos)
    vrtx = (u4(0x132, len(pos)) + b''.join(f4(*p, 1.0) for p in pos) + u4(len(nrm)) + b''.join(f4(*q, 1.0) for q in nrm)
            + u4(0, 0) + u4(len(uvs)) + b''.join(f4(*uv) for uv in uvs) + b'\0' * 28)
    return C.Chunk(b'LIST', form=b'PRIM', kids=[C.Chunk(b'vrtx', vrtx), C.Chunk(b'bsph', f4(*c, 1.0, r)),
                   C.Chunk(b'face', b''.join(u4(a, b) for a, b in face)), C.Chunk(b'indx', u4(*indx))]), len(pos), len(uvs), len(indx)

def swap_mesh(stock, tris, textures, node=None, keep_children=False, log=print, extra=None):
    """stock: bytes of a stock .4x3. tris: [(texture key, verts)]; textures: {key: PIL image}. Returns new .4x3 bytes."""
    head, recs, tags, _ = read_map_bytes(stock)
    ni = [i for i, t in enumerate(tags) if t == b'NODE']
    if not ni: raise ValueError('stock model has no NODE record')
    tree = C.parse(recs[ni[0]])
    meshes = C.find_lists(tree, b'MESH') + C.find_lists(tree, b'MESP')
    if not meshes: raise ValueError('stock model has no MESH node')
    target = next((m for m in meshes if node and m.name() == node), meshes[0] if not node else None)
    if target is None: raise ValueError('no mesh node %r (have: %s)' % (node, ', '.join(m.name() or '?' for m in meshes)))
    mat_ids = [struct.unpack_from('<I', C.parse(r)[0].data)[0] for r, t in zip(recs, tags) if t == b'MATL']
    mat_id = mat_ids[0]
    # fresh ids for the new textures, above anything the model already uses
    used = []                       # every def! id in the file, including the ones inside the node tree
    def _ids(cs):
        for k in cs:
            if k.is_list: _ids(k.kids)
            elif k.cid == b'def!': used.append(struct.unpack_from('<I', k.data)[0])
    for r in recs: _ids(C.parse(r))
    nxt = max(used + [0]) + 1; tex_id = {}
    for k in textures: tex_id[k] = nxt; nxt += 1
    prim, nv, nu, ni_ = build_prim(tris, tex_id, mat_id)
    extra = extra or {}
    allmesh = {mm.name(): mm for mm in meshes}
    for en, etris in extra.items():           # other mesh nodes replaced by their own objects
        em = allmesh.get(en)
        if em is None: log('  no mesh node %r, skipped' % en); continue
        ep = build_prim(etris, tex_id, mat_id)[0]
        if em.form == b'MESP':
            em.form = b'MESH'; em.kids = [k for k in em.kids if not (k.is_list and k.form == b'PRGM') and k.cid != b'Avsq']
        em.kids = [ep if (k.is_list and k.form in (b'PRIM', b'MTGM')) else k for k in em.kids]
        if not any(k is ep for k in em.kids): em.kids.insert(0, ep)
    if target.form == b'MESP':      # compressed progressive mesh (models held by others): becomes a plain mesh node
        target.form = b'MESH'
        target.kids = [k for k in target.kids if not (k.is_list and k.form == b'PRGM') and k.cid != b'Avsq']
    target.kids = [prim if (k.is_list and k.form in (b'PRIM', b'MTGM')) else k for k in target.kids]   # MTGM = several PRIMs (multi-material geometry)
    if not any(k is prim for k in target.kids): target.kids.insert(0, prim)
    if not keep_children:
        # the game looks child nodes up by name (reload clip, silencer, ...), so they stay as named meshes (shrunk to a speck) instead of being deleted
        k0 = next(iter(textures)); e = 0.001
        dprim = build_prim([(k0, [((0, 0, 0), (0, 0), (0, 0, 1)), ((e, 0, 0), (1, 0), (0, 0, 1)), ((0, e, 0), (0, 1), (0, 0, 1))])], tex_id, mat_id)[0]
        def blank(m):
            if m.form == b'MESP': m.form = b'MESH'
            m.kids = [k for k in m.kids if not (k.is_list and k.form in (b'PRIM', b'MTGM', b'PRGM')) and k.cid != b'Avsq']
            m.kids.insert(0, dprim)
            for k in m.kids:
                if k.is_list and k.form in (b'MESH', b'MESP') and k.name() not in extra: blank(k)
        removed = []
        for k in target.kids:
            if k.is_list and k.form in (b'MESH', b'MESP') and k.name() not in extra: removed.append(k.name()); blank(k)
        if removed: log('  shrunk child meshes (kept as named, near-empty meshes): ' + ', '.join(str(n) for n in removed))
    newrecs = [C.pack(tree)]; newtags = [b'NODE']
    tex_recs = [texture_record(tex_id[k], k, textures[k]) for k in textures]
    old_tex = [(r, t) for r, t in zip(recs, tags) if t == b'TEXU'] if keep_children else []
    others = [(r, t) for r, t in zip(recs, tags) if t not in (b'NODE', b'TEXU')]
    out_recs = [r for r, _ in old_tex] + tex_recs + [r for r, _ in others] + newrecs
    out_tags = [t for _, t in old_tex] + [b'TEXU'] * len(tex_recs) + [t for _, t in others] + newtags
    log('  mesh %r: %d vertices, %d uvs, %d index entries, %d texture(s)' % (target.name(), nv, nu, ni_, len(textures)))
    return write_like(stock, out_recs, out_tags)


def write_like(stock, recs, tags):
    """Write records in the stock file's chunk order: the plain chunks (@nam, $bgc, Aupm, CLOK, ...) keep their place
    between the compressed records, since the loader reads them in sequence (CLOK after the NODE record)."""
    import zlib
    from .repack import chunks, chunk
    seq = [(c, stock[o:o + sz]) for c, o, sz, bad in chunks(stock, 12, len(stock))]
    bytag = {}
    for r, t in zip(recs, tags): bytag.setdefault(t, []).append(r)
    co = zlib.compressobj(9, zlib.DEFLATED, -15); body = b''; done = set()
    def emit(t):
        nonlocal body
        for r in bytag.get(t, []):
            z = co.compress(r) + co.flush(zlib.Z_SYNC_FLUSH)
            body += chunk(b'zip!', t + struct.pack('<I', len(r) + 4) + z)
        done.add(t)
    for c, d in seq:
        if c == b'zip!':
            t = d[:4]
            if t not in done: emit(t)
        else: body += chunk(c, d)
    for t in bytag:
        if t not in done: emit(t)
    return b'RIFF' + struct.pack('<I', len(body) + 4) + b'SCEN' + body


def mesh_bbox(stock, node=None):
    """Bounding box of the named (or first) mesh node of a stock model, from its vrtx chunk."""
    head, recs, tags, _ = read_map_bytes(stock)
    tree = C.parse(next(r for r, t in zip(recs, tags) if t == b'NODE'))
    meshes = C.find_lists(tree, b'MESH') + C.find_lists(tree, b'MESP')
    m = next((x for x in meshes if node and x.name() == node), meshes[0])
    if m.form == b'MESP':
        pg = next(k for k in m.kids if k.is_list and k.form == b'PRGM'); b = struct.unpack('<5f', next(k for k in pg.kids if k.cid == b'bsph').data)
        return [b[i] - b[4] for i in range(3)], [b[i] + b[4] for i in range(3)]
    prs = [k for k in m.kids if k.is_list and k.form == b'PRIM']
    if not prs:
        mt = next(k for k in m.kids if k.is_list and k.form == b'MTGM'); prs = [k for k in mt.kids if k.is_list and k.form == b'PRIM']
    P = []
    for pr in prs:
        vr = next(k for k in pr.kids if k.cid == b'vrtx').data; n = struct.unpack_from('<I', vr, 4)[0]
        P += [struct.unpack_from('<3f', vr, 8 + 16 * k) for k in range(n)]
    return [min(p[i] for p in P) for i in range(3)], [max(p[i] for p in P) for i in range(3)]


def swap_skin(stock, tris, textures, nodes, node_name=None, log=print):
    """Replace the skinned mesh (PMSK compressed / MESK) of a character or arms model with a plain MESK: every vertex belongs to
    one bone and is stored in that bone's own frame (rest pose), grouped per bone. tris: [(texture key, [(pos, uv, normal, [(bone name, weight)]) x3])]
    with positions in the model's rest-pose space. nodes: rigimport.load(stock)['nodes'] (rest-pose bone worlds, def! ids)."""
    import numpy as np
    head, recs, tags, _ = read_map_bytes(stock)
    ni = [i for i, t in enumerate(tags) if t == b'NODE']
    if not ni: raise ValueError('stock model has no NODE record')
    tree = C.parse(recs[ni[0]])
    skins = C.find_lists(tree, b'PMSK') + C.find_lists(tree, b'MESK')
    if not skins: raise ValueError('stock model has no skinned mesh')
    target = next((m for m in skins if node_name and m.name() == node_name), skins[0])
    bl = next((k for k in target.kids if k.is_list and k.form == b'bone'), None)
    if bl is None: raise ValueError('skinned mesh has no bone list')
    ids = [struct.unpack_from('<I', k.data)[0] for k in bl.kids if not k.is_list]
    bydef = {n['defid']: i for i, n in enumerate(nodes) if n['defid'] is not None}
    allowed = [bydef[i] for i in ids if i in bydef]            # node indices, in the stock bone-list order
    if not allowed: raise ValueError('could not match the stock bone list to nodes')
    aset = {ni_: g for g, ni_ in enumerate(allowed)}
    byname = {n['name']: i for i, n in enumerate(nodes)}
    import re
    def resolve(name):
        i = byname.get(name, byname.get(re.sub(r'\.\d{3}$', '', name)))
        while i is not None and i >= 0:
            if i in aset: return aset[i]
            i = nodes[i]['parent']
        return None
    apos = np.array([nodes[i]['world'][:3, 3] for i in allowed])
    Winv = [np.linalg.inv(nodes[i]['world']) for i in allowed]
    # fresh ids for the new textures, above anything the file uses
    used = []
    def _ids(cs):
        for k in cs:
            if k.is_list: _ids(k.kids)
            elif k.cid == b'def!': used.append(struct.unpack_from('<I', k.data)[0])
    for r in recs: _ids(C.parse(r))
    nxt = max(used + [0]) + 1; tex_id = {}
    for k in textures: tex_id[k] = nxt; nxt += 1
    skim_old = next((k for k in target.kids if k.is_list and k.form in (b'PSKM', b'SKIM')), None)
    mat_id = None
    if skim_old is not None:
        mk = next((k for k in skim_old.kids if k.cid == b'MATL'), None)
        if mk is not None: mat_id = struct.unpack_from('<I', mk.data)[0]
    if mat_id is None: mat_id = next(struct.unpack_from('<I', C.parse(r)[0].data)[0] for r, t in zip(recs, tags) if t == b'MATL')
    # bone per vertex (by position + normal), rigid: the heaviest weight, after folding bones the model does not list into their parents
    vbone = {}; fallback = 0
    def vkey(p, n): return (tuple(round(x, 5) for x in p), tuple(round(x, 4) for x in n))
    for _, vs in tris:
        for p, uv, n, w in vs:
            k = vkey(p, n)
            if k in vbone: continue
            acc = {}
            for gname, wt in w:
                g = resolve(gname)
                if g is not None and wt > 0: acc[g] = acc.get(g, 0.0) + wt
            if acc: vbone[k] = max(acc, key=acc.get)
            else:
                fallback += 1; vbone[k] = int(np.argmin(np.linalg.norm(apos - np.array(p), axis=1)))
    used_g = sorted(set(vbone.values())); gidx = {g: i for i, g in enumerate(used_g)}
    # local vertex lists per bone group, then global order = group order
    local = {g: {} for g in used_g}
    for _, vs in tris:
        for p, uv, n, w in vs:
            k = vkey(p, n); g = vbone[k]
            if k not in local[g]: local[g][k] = (len(local[g]), p, n)
    start = {}; off = 0
    for g in used_g: start[g] = off; off += len(local[g])
    if off > 65535: raise ValueError('mesh too big: %d vertices (limit 65535)' % off)
    pos = [None] * off; nrm = [None] * off; limbs = []
    for g in used_g:
        Wi = Winv[g]; pl = []
        for k, (li, p, n) in local[g].items():
            q = Wi[:3, :3] @ np.array(p) + Wi[:3, 3]; m = Wi[:3, :3] @ np.array(n); m = m / (np.linalg.norm(m) or 1.0)
            pos[start[g] + li] = tuple(float(x) for x in q); nrm[start[g] + li] = tuple(float(x) for x in m); pl.append(q)
        pl = np.array(pl); c = (pl.min(0) + pl.max(0)) / 2; r = float(np.linalg.norm(pl - c, axis=1).max())
        limbs.append(f4(*[float(x) for x in c], 1.0, r) + u4(start[g], len(local[g])))
    keys = []
    for t, _ in tris:
        if t not in keys: keys.append(t)
    umap, uvs = {}, []; face = [(0x90, mat_id)]; indx = []; first = True
    for key in keys:
        group = [vs for t, vs in tris if t == key]
        face.append((0x80, tex_id[key]))
        if first: face.append((0x1000, 0x10002)); first = False
        for vs in group:
            indx.append(3)
            for p, uv, n, w in vs:
                k = vkey(p, n); g = vbone[k]
                uk = (round(uv[0], 5), round(uv[1], 5))
                if uk not in umap: umap[uk] = len(uvs); uvs.append((uv[0], 1.0 - uv[1]))
                indx.append((start[g] + local[g][k][0]) | (umap[uk] << 16))
        face.append((5, len(group)))
    if len(uvs) > 65535: raise ValueError('too many uvs: %d (limit 65535)' % len(uvs))
    vrtx = (u4(0x132, off) + b''.join(f4(*p, 1.0) for p in pos) + u4(off) + b''.join(f4(*q, 1.0) for q in nrm)
            + u4(0, 0) + u4(len(uvs)) + b''.join(f4(*uv) for uv in uvs) + b'\0' * 28)
    # model bounding sphere: the stock one's centre (same frame), grown to cover the new vertices
    ob = next((k.data for k in (skim_old.kids if skim_old else []) if k.cid == b'bsph'), None)
    wp = np.array([p for _, vs in tris for p, _, _, _ in vs])
    if ob and len(ob) >= 20:
        sb = struct.unpack('<5f', ob[:20]); c = np.array(sb[:3]); r0 = sb[4]
    else: c = (wp.min(0) + wp.max(0)) / 2; r0 = 0.0
    r = max(r0, float(np.linalg.norm(wp - c, axis=1).max()) * 1.05)
    skim = C.Chunk(b'LIST', form=b'SKIM', kids=[C.Chunk(b'vrtx', vrtx), C.Chunk(b'bsph', f4(*[float(x) for x in c], 1.0, r)),
                   C.Chunk(b'face', b''.join(u4(a, b) for a, b in face)), C.Chunk(b'indx', u4(*indx)), C.Chunk(b'limb', b''.join(limbs))])
    newbl = C.Chunk(b'LIST', form=b'bone', kids=[C.Chunk(b'NODE', u4(ids[ids_i])) for ids_i in
                    [ids.index(nodes[allowed[g]]['defid']) for g in used_g]])
    kids = []
    for k in target.kids:
        if k is skim_old: kids.append(skim)
        elif k is bl: kids.append(newbl)
        elif not k.is_list and k.cid in (b'Avsq', b'bnim', b'pvot'): continue
        else: kids.append(k)
    target.form = b'MESK'; target.kids = kids
    tex_recs = [texture_record(tex_id[k], k, textures[k]) for k in textures]
    out_recs = [r for r, t in zip(recs, tags) if t == b'TEXU'] + tex_recs + [r for r, t in zip(recs, tags) if t not in (b'NODE', b'TEXU')] + [C.pack(tree)]
    out_tags = [b'TEXU'] * (sum(1 for t in tags if t == b'TEXU') + len(tex_recs)) + [t for t in tags if t not in (b'NODE', b'TEXU')] + [b'NODE']
    if fallback: log('  %d vertices had no usable weights: attached to the nearest bone' % fallback)
    log('  skinned mesh %r: %d vertices on %d of %d bones, %d uvs, %d index entries' % (target.name(), off, len(used_g), len(allowed), len(uvs), len(indx)))
    return write_like(stock, out_recs, out_tags)
