"""DXT1 / DXT5 encoding with numpy only (Blender ships numpy but not Pillow). Same entry points as the tools' texio.py.
An image is an NpImage: .size = (w, h) and .arr = uint8 array (h, w, 4), top row first."""
import numpy as np

class NpImage:
    def __init__(self, arr):
        self.arr = np.ascontiguousarray(arr, dtype=np.uint8); self.size = (self.arr.shape[1], self.arr.shape[0])

def _blocks(a):
    h, w = a.shape[:2]; bh, bw = max(1, h // 4), max(1, w // 4)
    if h < 4 or w < 4:
        a = np.pad(a, ((0, max(0, 4 - h)), (0, max(0, 4 - w)), (0, 0)), mode='edge'); h, w = a.shape[:2]; bh, bw = h // 4, w // 4
    return a.reshape(bh, 4, bw, 4, 4).transpose(0, 2, 1, 3, 4).reshape(bh * bw, 16, 4).astype(np.float32)

def _to565(c):
    c = np.clip(np.rint(c), 0, 255)
    r = np.rint(c[..., 0] * 31 / 255).astype(np.uint16); g = np.rint(c[..., 1] * 63 / 255).astype(np.uint16); b = np.rint(c[..., 2] * 31 / 255).astype(np.uint16)
    return (r << 11) | (g << 5) | b

def _from565(v):
    r = ((v >> 11) & 31).astype(np.float32) * 255 / 31; g = ((v >> 5) & 63).astype(np.float32) * 255 / 63; b = (v & 31).astype(np.float32) * 255 / 31
    return np.stack([r, g, b], -1)

def _dxt1_color(blk):
    """blk (n,16,4) float -> (n, 8) uint8 colour blocks (4-colour mode, no punch-through alpha)."""
    rgb = blk[..., :3]
    lo, hi = rgb.min(1), rgb.max(1)
    inset = (hi - lo) / 16.0; lo = lo + inset; hi = hi - inset            # shrink the bbox a little: classic range-fit improvement
    c0, c1 = _to565(hi), _to565(lo)
    swap = c0 < c1; c0, c1 = np.where(swap, c1, c0), np.where(swap, c0, c1)
    equal = c0 == c1
    p0, p1 = _from565(c0), _from565(c1)
    pal = np.stack([p0, p1, (2 * p0 + p1) / 3, (p0 + 2 * p1) / 3], 1)      # (n,4,3)
    d = ((rgb[:, :, None, :] - pal[:, None, :, :]) ** 2).sum(-1)           # (n,16,4)
    idx = d.argmin(-1).astype(np.uint32); idx[equal] = 0
    bits = np.zeros(len(blk), np.uint32)
    for i in range(16): bits |= idx[:, i] << (2 * i)
    out = np.zeros((len(blk), 8), np.uint8)
    out[:, 0] = c0 & 255; out[:, 1] = c0 >> 8; out[:, 2] = c1 & 255; out[:, 3] = c1 >> 8
    for k in range(4): out[:, 4 + k] = (bits >> (8 * k)) & 255
    return out

def _dxt5_alpha(blk):
    a = blk[..., 3]; lo, hi = a.min(1), a.max(1)
    a0, a1 = np.rint(hi).astype(np.int32), np.rint(lo).astype(np.int32)    # a0 > a1: 8-value mode
    pal = np.stack([a0, a1] + [((7 - i) * a0 + i * a1) / 7.0 for i in range(1, 7)], 1).astype(np.float32)
    d = np.abs(a[:, :, None] - pal[:, None, :]); idx = d.argmin(-1).astype(np.uint64)
    idx[a0 == a1] = 0
    bits = np.zeros(len(blk), np.uint64)
    for i in range(16): bits |= idx[:, i] << np.uint64(3 * i)
    out = np.zeros((len(blk), 8), np.uint8); out[:, 0] = a0; out[:, 1] = a1
    for k in range(6): out[:, 2 + k] = ((bits >> np.uint64(8 * k)) & np.uint64(255)).astype(np.uint8)
    return out

def _level(a, alpha):
    blk = _blocks(a); col = _dxt1_color(blk)
    return (np.concatenate([_dxt5_alpha(blk), col], 1) if alpha else col).tobytes()

def _half(a):
    h, w = a.shape[:2]; a = a.astype(np.float32)
    if h > 4: a = (a[0:h:2] + a[1:h:2]) / 2
    if w > 4: a = (a[:, 0:w:2] + a[:, 1:w:2]) / 2
    return np.rint(a).astype(np.uint8)

def _encode(im, alpha):
    a = im.arr; h, w = a.shape[:2]
    assert w & (w - 1) == 0 and h & (h - 1) == 0 and w >= 4 and h >= 4, 'texture size must be a power of two, at least 4x4'
    out = []; mips = 0
    while True:
        out.append(_level(a, alpha)); mips += 1
        if a.shape[0] <= 4 or a.shape[1] <= 4: break
        a = _half(a)
    return w, h, mips, b''.join(out)

def encode_dxt1(im): return _encode(im, False)
def encode_dxt5(im): return _encode(im, True)
